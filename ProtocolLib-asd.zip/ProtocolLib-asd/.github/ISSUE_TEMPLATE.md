_Follow this template except for feature requests. Use pastebin when providing /protocol dump and any relevant errors._

Make sure you've done the following:
- [ ] You're using the latest build for your server version
- [ ] This isn't fixed in a recent development build
- [ ] This isn't an issue caused by another plugin
- [ ] You've checked for duplicate issues
- [ ] You didn't use `/reload`

Debug paste link:

Description and relevant errors:
