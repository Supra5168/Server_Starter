package com.comphenix.protocol.utility;

/**
 * Represents an object that has been generated using ByteBuddy.
 *
 * @author Pim
 */
public interface ByteBuddyGenerated {

}
