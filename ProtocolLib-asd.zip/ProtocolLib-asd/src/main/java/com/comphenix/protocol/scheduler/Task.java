package com.comphenix.protocol.scheduler;

public interface Task {
    void cancel();
}
