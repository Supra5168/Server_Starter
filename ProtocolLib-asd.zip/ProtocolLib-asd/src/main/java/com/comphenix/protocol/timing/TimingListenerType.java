package com.comphenix.protocol.timing;

public enum TimingListenerType {

    ASYNC_INBOUND, ASYNC_OUTBOUND, SYNC_INBOUND, SYNC_OUTBOUND;
}
